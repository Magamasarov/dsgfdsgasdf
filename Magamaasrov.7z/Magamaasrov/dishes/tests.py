from django.test import TestCase

# Create your tests here.

from django.db import models


from django.test import TestCase

from .models import YourModel

from django.utils import timezone

class YourModelTest(TestCase):
    def create_your_model(self, title="only a test", body="just a test description"):
        return YourModel.objects.create(title=title, body=body, created_at=timezone.now())

    def test_model_creation(self):
        w = self.create_your_model()
        self.assertTrue(isinstance(w, YourModel))
        self.assertEqual(w.__str__(), w.title)
