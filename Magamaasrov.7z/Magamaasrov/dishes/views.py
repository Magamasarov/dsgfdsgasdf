from django.shortcuts import render, redirect

# Create your views here.
from django.shortcuts import (render, get_object_or_404)
from .models import Dishes
def dish_list(request):
    dishes = Dishes.objects.all()
    return render(request, 'dishes/dish_list.html', {'dishes': dishes})
"templates/dishes" "dish_list.html"
