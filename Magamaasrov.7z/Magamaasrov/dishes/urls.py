from . import views
from django.urls import path
urlpatterns = [
    path('', views.dish_list, name='dish_list'),
]
